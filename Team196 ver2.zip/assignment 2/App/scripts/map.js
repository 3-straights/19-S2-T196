mapboxgl.accessToken = 'pk.eyJ1IjoiaW5maW5pdHlrYWkiLCJhIjoiY2swemU1dmJzMDAyazNnbnR2Y2t5M3p6YiJ9.x2eR57RbO3WuXy5zsMV6FA';
let map = new mapboxgl.Map({
  container: 'map',
  center: [144.9648731,-37.8182711],
  zoom: 8,
  style: 'mapbox://styles/mapbox/streets-v9'
});


//clear all markers and reset data if user accidentally click on the map before setting departure and arrival
function clearMarker()
{
  if (wayPointslat.length>0)
  {
    objects.data.geometry.coordinates=[];
    wayPointslat=[];
    wayPointslng=[];
    for (var i = 0; i < currentMarkers.length; i++) {
      currentMarkers[i].remove();
    }
    currentMarkers=[];

  }
}


function findAPIPort(nameOfPort) //finding the input port name in the storage key, and using the index to find it's other informations.
{
let portFound; //creating value that store index
let allAPIPorts = JSON.parse(localStorage.getItem('portInformation')).name;
let locations=
{

    lon:[],
    lat:[],
    name:[],
    country:[],
    size: [],
    type: [],
    locprecision: []
};

portFound = allAPIPorts.findIndex(
    function(arrayItem)
    {
        return arrayItem.toUpperCase() == nameOfPort; //if non found, the portfound will be -1 ///toUpperCase ensuring no capslock sensitivity
    }
  )

if (portFound !== -1)//if present
{
  locations.lon.push(JSON.parse(localStorage.getItem("portInformation")).lng[portFound]);
  locations.lat.push(JSON.parse(localStorage.getItem("portInformation")).lat[portFound]);
  locations.name.push(JSON.parse(localStorage.getItem("portInformation")).name[portFound]);
  locations.country.push(JSON.parse(localStorage.getItem("portInformation")).country[portFound]);
  locations.size.push(JSON.parse(localStorage.getItem("portInformation")).size[portFound]);
  locations.type.push(JSON.parse(localStorage.getItem("portInformation")).type[portFound]);
  locations.locprecision.push(JSON.parse(localStorage.getItem("portInformation")).locprecision[portFound]);
  if (currentMarkers.length==0)//if the array is empty, markers will be printed out on the map
  {
    let inimarker = new mapboxgl.Marker({ "color": "#00ff1e" });
    inimarker.setLngLat([locations.lon[0], locations.lat[0]]);

    //set port name on corresponding popup
    let popup = new mapboxgl.Popup({ offset: 45});
    popup.setText(locations.name[0].toString());

    //set popup on marker
    inimarker.setPopup(popup)

    // Display the marker.
    inimarker.addTo(map);

    // Display the popup.
    popup.addTo(map);

    //for reseting purpose,it will remove the marker one by one later
    currentMarkers.push(inimarker);

  }
  else //if the array contain items
  {
    let finmarker = new mapboxgl.Marker({ "color": "#ff0d00" });
    finmarker.setLngLat([locations.lon[0], locations.lat[0]]);

    //set port name on corresponding popup
    let popup = new mapboxgl.Popup({ offset: 45});
    popup.setText(locations.name[0].toString());

    //set popup on marker
    finmarker.setPopup(popup)

    // Display the marker.
    finmarker.addTo(map);

    // Display the popup.
    popup.addTo(map);

    //for reseting purpose,it will remove the marker one by one later
    currentMarkers.push(finmarker);
  }



//these if loops are to ensure that only 2 pair of coordinates can be stored in a time(initial port and final port), else it will be refresh again.
  if (localStorage.getItem('portCoord') == null)
  {

    localStorage.setItem('portCoord', JSON.stringify(locations));

  }
  else if (localStorage.getItem('portCoord') !== null && JSON.parse(localStorage.getItem('portCoord')).lon.length >= 2)
  {
    localStorage.removeItem('portCoord');
    localStorage.setItem('portCoord', JSON.stringify(locations)); //updating the storage key
  }

  else if (localStorage.getItem('portCoord') !== null && JSON.parse(localStorage.getItem('portCoord')).lon.length < 2)
  {

    let object = JSON.parse(localStorage.getItem('portCoord')); //pushing the object into an array

    object.lon.push(locations.lon[0]);
    object.lat.push(locations.lat[0]);
    object.name.push(locations.name[0]);
    object.country.push(locations.country[0])
    object.size.push(locations.size[0])
    object.type.push(locations.type[0])
    object.locprecision.push(locations.locprecision[0])
    localStorage.setItem('portCoord', JSON.stringify(object));

  }


}

else if (document.getElementById("departure").innerHTML == '' && portFound == -1)//create port if no port founds in the storage key API
{
  let  other_name, other_country, other_type, other_size, other_locPrec;

  if (currentMarkers.length==0)//similar to the if loop above
  {

   other_name = document.getElementById('depPort').value;
   other_country = document.getElementById('depCountry').value;
   other_size = document.getElementById('depSize').value;
   other_type = document.getElementById('depType').value;
   other_locPrec = document.getElementById('depLocPrec').value;
   if (locations.lon.length==0)//ensure that locations only stores one a time
   {
     locations.lon.push(JSON.parse(localStorage.getItem("otherdepcoordinate"))[0]);
     locations.lat.push(JSON.parse(localStorage.getItem("otherdepcoordinate"))[1]);
   }
   else
   {
     locations.lon=[];//else making the values empty again, then store the new one
     locations.lat=[];
     locations.lon.push(JSON.parse(localStorage.getItem("otherdepcoordinate"))[0]);
     locations.lat.push(JSON.parse(localStorage.getItem("otherdepcoordinate"))[1]);
   }


  }

  else //this is to create destination port 'other'
  {

    other_name = document.getElementById('desPort').value;
    other_country = document.getElementById('desCountry').value;
    other_size = document.getElementById('desSize').value;
    other_type = document.getElementById('desType').value;
    other_locPrec = document.getElementById('desLocPrec').value;
    locations.lon.push(JSON.parse(localStorage.getItem("otherdescoordinate"))[0]);
    locations.lat.push(JSON.parse(localStorage.getItem("otherdescoordinate"))[1]);
  }



    locations.name.push(other_name)
    locations.country.push(other_country)
    locations.size.push(other_size)
    locations.type.push(other_type)
    locations.locprecision.push(other_locPrec)

    if (currentMarkers.length==0)
    {
      let inimarker = new mapboxgl.Marker({ "color": "#00ff1e" });
      inimarker.setLngLat([locations.lon[0], locations.lat[0]]);

      //set port name on corresponding popup
      let popup = new mapboxgl.Popup({ offset: 45});
      popup.setText(locations.name[0].toString());

      //set popup on marker
      inimarker.setPopup(popup)

      // Display the marker.
      inimarker.addTo(map);

      // Display the popup.
      popup.addTo(map);

      //for reseting purpose,it will remove the marker one by one later
      currentMarkers.push(inimarker);

    }
    else
    {
      let finmarker = new mapboxgl.Marker({ "color": "#ff0d00" });
      finmarker.setLngLat([locations.lon[0], locations.lat[0]]);

      //set port name on corresponding popup
      let popup = new mapboxgl.Popup({ offset: 45});
      popup.setText(locations.name[0].toString());

      //set popup on marker
      finmarker.setPopup(popup)

      // Display the marker.
      finmarker.addTo(map);

      // Display the popup.
      popup.addTo(map);

      //for reseting purpose,it will remove the marker one by one later
      currentMarkers.push(finmarker);
    }


  if (localStorage.getItem('portCoord') == null)
  {

    localStorage.setItem('portCoord', JSON.stringify(locations));

  }
  else if (localStorage.getItem('portCoord') !== null && JSON.parse(localStorage.getItem('portCoord')).lon.length >= 2)
  {
    localStorage.removeItem('portCoord');
    localStorage.setItem('portCoord', JSON.stringify(locations));
  }

  else if (localStorage.getItem('portCoord') !== null && JSON.parse(localStorage.getItem('portCoord')).lon.length < 2)
  {

    let object = JSON.parse(localStorage.getItem('portCoord'));

    object.lon.push(locations.lon[0]);
    object.lat.push(locations.lat[0]);
    object.name.push(locations.name[0]);
    object.country.push(locations.country[0]);
    object.type.push(locations.type[0]);
    object.size.push(locations.size[0]);
    object.locprecision.push(locations.locprecision[0])
    localStorage.setItem('portCoord', JSON.stringify(object));

  }
}
else
  {
    alert('Please insert a valid departure port name or type "Other"');
  }
}


function otheriniInformation() //getting the cooridinates of created departure port(if new port created) with valid address
{
  if (document.getElementById("depAddress").value!=="")
{
    jsonpinilocation(document.getElementById('depAddress').value) //using jsonp to extract the address, and find the coordinates
}
else
  {
    alert("Please Enter a valid address")
  }
}

function otherfinInformation()//getting the cooridinates of created destination port(if new port created) with valid address
{
  if(document.getElementById("desAddress").value!=="")
{

    jsonpfinlocation(document.getElementById('desAddress').value)//using jsonp to extract the address, and find the coordinates
}
else
  {
    alert("Please Enter a valid address")//if it's not a valid address
  }


}


function getIntWeather() //getting departure port weather
{
  //seperate year, month, and day
  let dateSet = JSON.parse(localStorage.getItem('date'));
  let year = dateSet.substring(0,4);
  let month = String(dateSet.substring(5,7) - 1);
  //month have to minus 1 to have the correct data
  let day = dateSet.substring(8,10);
  if (day < 10)
  {
    day = day.substring(1,2);
  }
  let unixTime = Math.round((new Date(year, month, day)).getTime() / 1000);//Change local date to UNIX Time
  if   (!localStorage.getItem('unixTime'))
  {
    localStorage.setItem('unixTime', JSON.stringify(unixTime));
  }

  else if (localStorage.getItem('unixTime') !== null)
  {
    localStorage.removeItem('unixTime');
    localStorage.setItem('unixTime', JSON.stringify(unixTime));
  }
  //Request to DarkShy Api
  let url = "https://api.darksky.net/forecast/2f325944bde3b00d86bdabaf4ac091be/" +
            JSON.parse(localStorage.getItem('portCoord')).lat[0] + "," + JSON.parse(localStorage.getItem('portCoord')).lon[0] + "," +
            unixTime + "?exclude=minutely,hourly&units=si&callback=getIntWeatherData";
  let script = document.createElement('script'); // create script element in HTML
  script.src = url; // set link to sources
  document.body.appendChild(script); // to append script element into body.
}

// Callback function to retrieve weather data
function getIntWeatherData(data)
{
  let weatherInt = data.currently.summary;

  //set marker coordinates
  let marker = new mapboxgl.Marker({ "color": "#00FF00" });
  marker.setLngLat([JSON.parse(localStorage.getItem('portCoord')).lon[0], JSON.parse(localStorage.getItem('portCoord')).lat[0]]);

  //set port name and weather on corresponding popup
  let popup = new mapboxgl.Popup({ offset: 45});
  popup.setText(JSON.parse(localStorage.getItem('portCoord')).name[0].toString() + ": " + weatherInt);

  if (!localStorage.getItem('intWeather'))
  {
    localStorage.setItem('intWeather', JSON.stringify(weatherInt))
  }
  else if (localStorage.getItem('intWeather') !== null)
  {
    localStorage.removeItem('intWeather')
    localStorage.setItem('intWeather', JSON.stringify(weatherInt))
  }

  //set popup on marker
  marker.setPopup(popup)

  // Display the marker.
  marker.addTo(map);

  // Display the popup.
  popup.addTo(map);

  //for reseting purpose,it will remove the marker one by one later
  currentMarkers.push(marker);

  return weatherInt
}

function getFinWeather() //getting destination port weather
{
  //Request to DarkShy Api
  let url = "https://api.darksky.net/forecast/2f325944bde3b00d86bdabaf4ac091be/" +
            JSON.parse(localStorage.getItem('portCoord')).lat[1] + "," + JSON.parse(localStorage.getItem('portCoord')).lon[1] + "," +
            JSON.parse(localStorage.getItem('unixTime')) + "?exclude=minutely,hourly&units=si&callback=getFinWeatherData";
  let script = document.createElement('script'); // create script element in HTML
  script.src = url; // set link to sources
  document.body.appendChild(script); // to append script element into body.
}

// Callback function to retrieve weather data
function getFinWeatherData(data) {
  let weatherSevenDays = data.currently.summary;

  if (!localStorage.getItem('finWeather'))
  {
    localStorage.setItem('finWeather', JSON.stringify(weatherSevenDays))
  }
  else if (localStorage.getItem('finWeather') !== null)
  {
    localStorage.removeItem('finWeather')
    localStorage.setItem('finWeather', JSON.stringify(weatherSevenDays))
  }

  //set marker coordinates
  let marker = new mapboxgl.Marker({ "color": "#FF0000" });
  marker.setLngLat([JSON.parse(localStorage.getItem('portCoord')).lon[1], JSON.parse(localStorage.getItem('portCoord')).lat[1]]);

  //set port name and weather on corresponding popup
  let popup = new mapboxgl.Popup({ offset: 45});
  popup.setText(JSON.parse(localStorage.getItem('portCoord')).name[1].toString() + ": " + weatherSevenDays);

  //set popup on marker
  marker.setPopup(popup)

  // Display the marker.
  marker.addTo(map);

  // Display the popup.
  popup.addTo(map);

  //for reseting purpose,it will remove the marker one by one later
  currentMarkers.push(marker);

  return weatherSevenDays;
}


let object = {
type: "geojson",
data: {
type: "Feature",
properties: {},
geometry: {
type: "LineString",
coordinates: []
}
}
};

let currentMarkers=[];
let wayPointslat=[];
let wayPointslng=[];


map.on('click', function (e)
{
  object.data.geometry.coordinates.push([JSON.stringify(e.lngLat.lng),JSON.stringify(e.lngLat.lat)]);
  //Request to DarkShy Api
  let url = "https://api.darksky.net/forecast/2f325944bde3b00d86bdabaf4ac091be/" +
            JSON.stringify(e.lngLat.lat) + "," + JSON.stringify(e.lngLat.lng) + "," +
            JSON.parse(localStorage.getItem('unixTime')) + "?exclude=minutely,hourly&units=si&callback=getWeatherDataWayPoints";
  let script = document.createElement('script'); // create script element in HTML
  script.src = url; // set link to sources
  document.body.appendChild(script); // to append script element into body.
})

function getWeatherDataWayPoints(data)
{
    let weatherWayPoint = data.currently.summary;

    //set coordinate for marker
    let markers = new mapboxgl.Marker({ "color": "#FF8C00" });
    markers.setLngLat([data.longitude,data.latitude]);

    //set weather on corresponding popup
    let popup = new mapboxgl.Popup({ offset: 45});
    popup.setText(weatherWayPoint);

    //set popup on marker
    markers.setPopup(popup)

    // Display the marker.
    markers.addTo(map);

    // Display the popup.
    popup.addTo(map);

    wayPointslat.push(data.latitude)//calculation purpose
    wayPointslng.push(data.longitude)
    currentMarkers.push(markers);//for reset purpose
}

function zoom()
{
  map.flyTo({
center: [
(JSON.parse(localStorage.getItem("portCoord")).lon[0]+JSON.parse(localStorage.getItem("portCoord")).lon[1])/2,(JSON.parse(localStorage.getItem("portCoord")).lat[0]+JSON.parse(localStorage.getItem("portCoord")).lat[1])/2],
zoom:2.1,
speed:1.5
});
alert('Start choosing your route waypoint(s) by clicking around the map along(green marker is start, red marker is end), and select "set route" once done')
}



function showRoute(){

  object.data.geometry.coordinates.unshift([JSON.parse(localStorage.getItem("portCoord")).lon[0].toString(),JSON.parse(localStorage.getItem("portCoord")).lat[0].toString()])
  object.data.geometry.coordinates.push([JSON.parse(localStorage.getItem("portCoord")).lon[1].toString(),JSON.parse(localStorage.getItem("portCoord")).lat[1].toString()])
  map.addLayer({
  id: "routes",
  type: "line",
  source: object,
  layout: { "line-join": "round", "line-cap": "round" },
  paint: { "line-color": "#888", "line-width": 6 }
  });
  localStorage.setItem('wayPointsCoordinate',JSON.stringify(object.data.geometry.coordinates))

}

function reset()
{
  removeLayerWithId('routes')
  if (currentMarkers!==null) {
      for (var i = 0; i < currentMarkers.length; i++) {
        currentMarkers[i].remove();
      }
}
currentMarkers=[];
wayPointlng=[];
wayPointslat=[];


}
//called out by 'reset' button in map.html to remove all the stored coordinates value and marker
function resetStorage()
{
  localStorage.removeItem('wayPointsCoordinate')
  localStorage.removeItem('routeDistance')
  object.data.geometry.coordinates=[];
  d=0;

  localStorage.setItem('wayPointsCoordinate',JSON.stringify(object.data.geometry.coordinates))
  localStorage.setItem('routeDistance', JSON.stringify(d))


}

//a function that converts value into radian
function toRadians(value)
{
  return (value)*Math.PI/180
}

function calculateDistance() //function that calculates the distance of route using the given
{
  let earthRadius = 6371e3; // metres earth radius
  let d =0;
if (localStorage.getItem('routeDistance')!== null)
{

  localStorage.removeItem('routeDistance')//removing routeDistance value in storage key for update
}
  wayPointslat.unshift((JSON.parse(localStorage.getItem("portCoord"))).lat[0])
  wayPointslng.unshift((JSON.parse(localStorage.getItem("portCoord"))).lon[0])

  wayPointslat.push((JSON.parse(localStorage.getItem("portCoord"))).lat[1])
  wayPointslng.push((JSON.parse(localStorage.getItem("portCoord"))).lon[1])

  for(i=0;i<wayPointslat.length-1;i++)
  {
    let lattitude1 = wayPointslat[i]
    let lattitude2 = wayPointslat[i+1]
    let longitude1=wayPointslng[i]
    let longitude2=wayPointslng[i+1]
    let difflattitude=toRadians((lattitude2-lattitude1))
    let difflongitude=toRadians((longitude2-longitude1));
    let a = Math.sin(difflattitude/2) * Math.sin(difflattitude/2) +(Math.cos(toRadians(lattitude1)) * Math.cos(toRadians(lattitude2)) *Math.sin(difflongitude/2) * Math.sin(difflongitude/2));

    console.log(earthRadius)
    console.log(a)
    let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    console.log(c)
     d += (earthRadius * c)/1000;

  }
  localStorage.setItem('routeDistance', JSON.stringify(d))

  return d; //returning the route distance
}
function calculateTime()
{
  let travelTime = Number(JSON.parse(localStorage.getItem('distanceCalculated')))/(Number(JSON.parse(localStorage.getItem('myShip')).maxSpeed)*0.51444);
  //1 knot = 0.51444m/s
  localStorage.setItem('totalTravelTime',JSON.stringify(travelTime));
}

function removeLayerWithId(idToRemove)//removing the marker layer on the map
{
	let hasPoly = map.getLayer(idToRemove)
	if (hasPoly !== undefined)
	{
		map.removeLayer(idToRemove)
		map.removeSource(idToRemove)
	}
}
function newDropoff(coords) {
  // Store the clicked point as a new GeoJSON feature with
  // two properties: `orderTime` and `key`
  var pt = turf.point(
    [coords.lng, coords.lat],
    {
      orderTime: Date.now(),
      key: Math.random()
    }
  );
  dropoffs.features.push(pt);
  new mapboxgl.Popup();

  marker.setLngLat([coords.lng, coords.lat]);

}

function updateDropoffs(geojson) {
  map.getSource('dropoffs-symbol')
    .setData(geojson);
}
function jsonpinilocation(targetLocation)//retrieving address to find coordinate with url for departure port
{
	let encodedLocation = encodeURIComponent(targetLocation);

	let url = "https://api.opencagedata.com/geocode/v1/json?q=" + encodedLocation + "&key=c3d93d98f0264ab196efc62f2bb1555a&jsonp=displayiniMap";

	let script = document.createElement('script');
	script.src = url;
	document.body.appendChild(script);

}
function jsonpfinlocation(targetLocation)//retrieving address to find coordinate with url for departure port
{

	let encodedLocation = encodeURIComponent(targetLocation);

	let url = "https://api.opencagedata.com/geocode/v1/json?q=" + encodedLocation + "&key=c3d93d98f0264ab196efc62f2bb1555a&jsonp=displayfinMap";

	let script = document.createElement('script');
	script.src = url;
	document.body.appendChild(script);

}
function displayiniMap(address) // all data passed to address variable
{

	let latRef = address.results[0].geometry.lat;
	let lngRef = address.results[0].geometry.lng;
if (localStorage.getItem("otherdepcoordinate")==null)
{
  localStorage.setItem("otherdepcoordinate",JSON.stringify([lngRef,latRef]))
}
else
{
  localStorage.removeItem("otherdepcoordinate")
  localStorage.setItem("otherdepcoordinate",JSON.stringify([lngRef,latRef]))
}

}
function displayfinMap(address) // all data passed to address variable to display the coordinate with marker on the map
{

	let latRef = address.results[0].geometry.lat;
	let lngRef = address.results[0].geometry.lng;

  if (localStorage.getItem("otherdescoordinate")==null)
  {
    localStorage.setItem("otherdescoordinate",JSON.stringify([lngRef,latRef]))
  }
  else
  {
    localStorage.removeItem("otherdescoordinate")
    localStorage.setItem("otherdescoordinate",JSON.stringify([lngRef,latRef]))
  }


}
