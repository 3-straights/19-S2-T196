function getIntWeather()
{
  //seperate year, month, and day
  let dateSet = JSON.parse(localStorage.getItem('date'));
  let year = dateSet.substring(0,4);
  let month = String(dateSet.substring(5,7) - 1);
  //month have to minus 1 to have the correct data
  let day = dateSet.substring(8,10);
  if (day < 10)
  {
    day = day.substring(1,2);
  }
  let unixTime = Math.round((new Date(year, month, day)).getTime() / 1000);//Change local date to UNIX Time
  if   (!localStorage.getItem('unixTime'))
  {
    localStorage.setItem('unixTime', JSON.stringify(unixTime));
  }

  else if (localStorage.getItem('unixTime') !== null)
  {
    localStorage.removeItem('unixTime');
    localStorage.setItem('unixTime', JSON.stringify(unixTime));
  }
  //Request to DarkShy Api
  let url = "https://api.darksky.net/forecast/2f325944bde3b00d86bdabaf4ac091be/" +
            JSON.parse(localStorage.getItem('portCoord')).lat[0] + "," + JSON.parse(localStorage.getItem('portCoord')).lon[0] + "," +
            unixTime + "?exclude=minutely,hourly&units=si&callback=getIntWeatherData";
  let script = document.createElement('script'); // create script element in HTML
  script.src = url; // set link to sources
  document.body.appendChild(script); // to append script element into body.
}

// Callback function to retrieve weather data
function getIntWeatherData(data)
{
  let weatherInt = data.currently.summary;

  if (!localStorage.getItem('intWeather'))
  {
    localStorage.setItem('intWeather', JSON.stringify(weatherInt))
  }
  else if (localStorage.getItem('intWeather') !== null)
  {
    localStorage.removeItem('intWeather')
    localStorage.setItem('intWeather', JSON.stringify(weatherInt))
  }

  return weatherInt
}

function getFinWeather()
{
  //Request to DarkShy Api
  let url = "https://api.darksky.net/forecast/2f325944bde3b00d86bdabaf4ac091be/" +
            JSON.parse(localStorage.getItem('portCoord')).lat[1] + "," + JSON.parse(localStorage.getItem('portCoord')).lon[1] + "," +
            JSON.parse(localStorage.getItem('unixTime')) + "?exclude=minutely,hourly&units=si&callback=getFinWeatherData";
  let script = document.createElement('script'); // create script element in HTML
  script.src = url; // set link to sources
  document.body.appendChild(script); // to append script element into body.
}

// Callback function to retrieve weather data
function getFinWeatherData(data) {
  let weatherSevenDays = data.currently.summary;

  if (!localStorage.getItem('finWeather'))
  {
    localStorage.setItem('finWeather', JSON.stringify(weatherSevenDays))
  }
  else if (localStorage.getItem('finWeather') !== null)
  {
    localStorage.removeItem('finWeather')
    localStorage.setItem('finWeather', JSON.stringify(weatherSevenDays))
  }

  return weatherSevenDays;
}
